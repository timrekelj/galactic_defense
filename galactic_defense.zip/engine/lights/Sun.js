import { Light } from "./Light.js"

export class Sun extends Light { }