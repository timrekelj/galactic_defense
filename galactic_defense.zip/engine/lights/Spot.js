import { Light } from "./Light.js"

export class Spot extends Light { }