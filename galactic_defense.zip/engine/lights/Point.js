import { Light } from "./Light.js"

export class Point extends Light { }